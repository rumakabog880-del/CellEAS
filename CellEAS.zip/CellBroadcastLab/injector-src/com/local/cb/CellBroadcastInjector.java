package com.local.cb;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

public final class CellBroadcastInjector {
    private static final String ACTION_EMERGENCY_CB =
            "android.provider.action.SMS_EMERGENCY_CB_RECEIVED";
    private static final String RECEIVE_EMERGENCY_BROADCAST =
            "android.permission.RECEIVE_EMERGENCY_BROADCAST";
    private static final String RECEIVE_SMS = "android.permission.RECEIVE_SMS";

    private CellBroadcastInjector() {
    }

    public static void main(String[] argv) throws Exception {
        disableHiddenApiChecks();
        Args args = Args.parse(argv);
        Context context = getSystemContext();

        AlertProfile profile = AlertProfile.from(args.type, args.category);
        Object message = createSmsCbMessage(args, profile);

        Intent intent = new Intent(ACTION_EMERGENCY_CB);
        intent.putExtra("message", (Parcelable) message);

        String receiverPackage = args.receiverPackage;
        if (receiverPackage == null || receiverPackage.length() == 0
                || "auto".equalsIgnoreCase(receiverPackage)) {
            receiverPackage = findCellBroadcastReceiverPackage(context, intent);
        }
        if (receiverPackage != null && receiverPackage.length() > 0) {
            intent.setPackage(receiverPackage);
        }

        sendEmergencyBroadcast(context, intent);

        System.out.println("OK sent " + profile.name + " category=" + profile.serviceCategory
                + " serial=" + args.serialNumber + " package="
                + (receiverPackage == null ? "<implicit>" : receiverPackage));
    }

    private static Context getSystemContext() throws Exception {
        Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
        Object thread = null;
        try {
            thread = activityThreadClass.getMethod("currentActivityThread").invoke(null);
        } catch (Throwable ignored) {
        }
        if (thread == null) {
            prepareLooperIfNeeded();
            thread = activityThreadClass.getMethod("systemMain").invoke(null);
        }
        Method getSystemContext = activityThreadClass.getDeclaredMethod("getSystemContext");
        getSystemContext.setAccessible(true);
        return (Context) getSystemContext.invoke(thread);
    }

    private static void prepareLooperIfNeeded() {
        if (Looper.myLooper() != null) {
            return;
        }
        try {
            Looper.prepareMainLooper();
        } catch (Throwable ignored) {
            try {
                Looper.prepare();
            } catch (Throwable ignoredToo) {
            }
        }
    }

    private static void disableHiddenApiChecks() {
        try {
            Class<?> vmRuntime = Class.forName("dalvik.system.VMRuntime");
            Method getRuntime = vmRuntime.getDeclaredMethod("getRuntime");
            Method setExemptions = vmRuntime.getDeclaredMethod(
                    "setHiddenApiExemptions", String[].class);
            Object runtime = getRuntime.invoke(null);
            setExemptions.invoke(runtime, (Object) new String[]{"L"});
        } catch (Throwable ignored) {
        }
    }

    private static String findCellBroadcastReceiverPackage(Context context, Intent probe) {
        try {
            PackageManager pm = context.getPackageManager();
            List<ResolveInfo> receivers = pm.queryBroadcastReceivers(probe, 0);
            String first = null;
            for (ResolveInfo info : receivers) {
                if (info == null || info.activityInfo == null) {
                    continue;
                }
                String pkg = info.activityInfo.packageName;
                if (first == null) {
                    first = pkg;
                }
                if (pkg != null && pkg.toLowerCase().contains("cellbroadcast")) {
                    return pkg;
                }
            }
            return first;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static void sendEmergencyBroadcast(Context context, Intent intent) throws Exception {
        Throwable orderedFailure = null;
        try {
            sendOrderedBroadcastAsAllUsers(context, intent);
            return;
        } catch (Throwable t) {
            orderedFailure = t;
        }

        try {
            context.sendBroadcast(intent, RECEIVE_EMERGENCY_BROADCAST);
            return;
        } catch (Throwable t) {
            RuntimeException failure = new RuntimeException(
                    "Both ordered and unordered emergency CB broadcasts failed");
            failure.addSuppressed(orderedFailure);
            failure.addSuppressed(t);
            throw failure;
        }
    }

    private static void sendOrderedBroadcastAsAllUsers(Context context, Intent intent)
            throws Exception {
        Class<?> userHandleClass = Class.forName("android.os.UserHandle");
        Field allField = userHandleClass.getDeclaredField("ALL");
        allField.setAccessible(true);
        Object userAll = allField.get(null);

        Method best = null;
        for (Method method : Context.class.getMethods()) {
            if (!"sendOrderedBroadcastAsUser".equals(method.getName())) {
                continue;
            }
            Class<?>[] params = method.getParameterTypes();
            if (params.length >= 8 && params[0] == Intent.class
                    && params[1].getName().equals("android.os.UserHandle")
                    && params[2] == String.class) {
                if (best == null || params.length > best.getParameterTypes().length) {
                    best = method;
                }
            }
        }
        if (best == null) {
            throw new NoSuchMethodException("sendOrderedBroadcastAsUser");
        }

        Class<?>[] params = best.getParameterTypes();
        Object[] callArgs = new Object[params.length];
        int stringCount = 0;
        int intCount = 0;
        for (int i = 0; i < params.length; i++) {
            Class<?> p = params[i];
            if (p == Intent.class) {
                callArgs[i] = intent;
            } else if (p.getName().equals("android.os.UserHandle")) {
                callArgs[i] = userAll;
            } else if (p == String.class) {
                callArgs[i] = stringCount++ == 0 ? RECEIVE_EMERGENCY_BROADCAST : null;
            } else if (p == int.class || p == Integer.TYPE) {
                callArgs[i] = intCount++ == 0 && params.length >= 10
                        ? getReceiveEmergencySmsAppOp() : -1;
            } else if (p == Bundle.class) {
                callArgs[i] = null;
            } else {
                callArgs[i] = null;
            }
        }
        best.invoke(context, callArgs);
    }

    private static int getReceiveEmergencySmsAppOp() {
        try {
            Class<?> appOps = Class.forName("android.app.AppOpsManager");
            for (String name : new String[]{"OP_RECEIVE_EMERGECY_SMS",
                    "OP_RECEIVE_EMERGENCY_SMS", "OP_NONE"}) {
                try {
                    Field field = appOps.getDeclaredField(name);
                    field.setAccessible(true);
                    return field.getInt(null);
                } catch (NoSuchFieldException ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
        return -1;
    }

    private static Object createSmsCbMessage(Args args, AlertProfile profile) throws Exception {
        Class<?> locationClass = Class.forName("android.telephony.SmsCbLocation");
        Class<?> cmasInfoClass = Class.forName("android.telephony.SmsCbCmasInfo");
        Class<?> etwsInfoClass = Class.forName("android.telephony.SmsCbEtwsInfo");
        Class<?> smsCbMessageClass = Class.forName("android.telephony.SmsCbMessage");

        Object location = constructLocation(locationClass, args.plmn);
        Object cmasInfo = constructCmasInfo(cmasInfoClass, profile);

        int messageFormat = args.cdma ? 2 : 1;
        int geographicalScope = args.cdma ? 1 : 0;
        int priority = args.priorityNormal ? 0 : getStaticInt(smsCbMessageClass,
                "MESSAGE_PRIORITY_EMERGENCY", 3);

        Constructor<?> full = findConstructor(smsCbMessageClass, 16);
        if (full != null) {
            full.setAccessible(true);
            return full.newInstance(messageFormat, geographicalScope, args.serialNumber, location,
                    profile.serviceCategory, args.language, 0, args.body, priority, null,
                    cmasInfo, args.maximumWaitSeconds, null, System.currentTimeMillis(),
                    args.slotIndex, args.subId);
        }

        Constructor<?> compact = findConstructor(smsCbMessageClass, 12);
        if (compact != null) {
            compact.setAccessible(true);
            return compact.newInstance(messageFormat, geographicalScope, args.serialNumber,
                    location, profile.serviceCategory, args.language, args.body, priority,
                    null, cmasInfo, args.slotIndex, args.subId);
        }

        for (Constructor<?> ctor : smsCbMessageClass.getDeclaredConstructors()) {
            if (ctor.getParameterTypes().length >= 10) {
                ctor.setAccessible(true);
                Object[] values = fallbackSmsCbConstructorArgs(ctor.getParameterTypes(),
                        messageFormat, geographicalScope, args.serialNumber, locationClass,
                        location, profile.serviceCategory, args.language, args.body, priority,
                        etwsInfoClass, cmasInfoClass, cmasInfo, args);
                return ctor.newInstance(values);
            }
        }

        throw new NoSuchMethodException("No usable SmsCbMessage constructor found");
    }

    private static Object[] fallbackSmsCbConstructorArgs(Class<?>[] params, int messageFormat,
            int geographicalScope, int serialNumber, Class<?> locationClass, Object location,
            int serviceCategory, String language, String body, int priority, Class<?> etwsInfoClass,
            Class<?> cmasInfoClass, Object cmasInfo, Args args) {
        Object[] values = new Object[params.length];
        int intIndex = 0;
        int stringIndex = 0;
        for (int i = 0; i < params.length; i++) {
            Class<?> p = params[i];
            if (p == int.class || p == Integer.TYPE) {
                int[] ints = new int[]{messageFormat, geographicalScope, serialNumber,
                        serviceCategory, 0, priority, args.maximumWaitSeconds, args.slotIndex,
                        args.subId};
                values[i] = ints[Math.min(intIndex, ints.length - 1)];
                intIndex++;
            } else if (p == long.class || p == Long.TYPE) {
                values[i] = System.currentTimeMillis();
            } else if (p == String.class) {
                values[i] = stringIndex++ == 0 ? language : body;
            } else if (p == locationClass) {
                values[i] = location;
            } else if (p == etwsInfoClass) {
                values[i] = null;
            } else if (p == cmasInfoClass) {
                values[i] = cmasInfo;
            } else {
                values[i] = null;
            }
        }
        return values;
    }

    private static Constructor<?> findConstructor(Class<?> cls, int parameterCount) {
        for (Constructor<?> ctor : cls.getDeclaredConstructors()) {
            if (ctor.getParameterTypes().length == parameterCount) {
                return ctor;
            }
        }
        return null;
    }

    private static Object constructLocation(Class<?> locationClass, String plmn) throws Exception {
        try {
            Constructor<?> ctor = locationClass.getDeclaredConstructor(String.class);
            ctor.setAccessible(true);
            return ctor.newInstance(plmn);
        } catch (NoSuchMethodException ignored) {
            try {
                Constructor<?> ctor = locationClass.getDeclaredConstructor(
                        String.class, int.class, int.class);
                ctor.setAccessible(true);
                return ctor.newInstance(plmn, -1, -1);
            } catch (NoSuchMethodException ignored2) {
                Constructor<?> ctor = locationClass.getDeclaredConstructor();
                ctor.setAccessible(true);
                return ctor.newInstance();
            }
        }
    }

    private static Object constructCmasInfo(Class<?> cmasInfoClass, AlertProfile profile)
            throws Exception {
        Constructor<?> ctor = cmasInfoClass.getDeclaredConstructor(
                int.class, int.class, int.class, int.class, int.class, int.class);
        ctor.setAccessible(true);
        return ctor.newInstance(profile.messageClass, profile.category, profile.responseType,
                profile.severity, profile.urgency, profile.certainty);
    }

    private static int getStaticInt(Class<?> cls, String fieldName, int fallback) {
        try {
            Field field = cls.getDeclaredField(fieldName);
            field.setAccessible(true);
            return field.getInt(null);
        } catch (Throwable ignored) {
            return fallback;
        }
    }

    private static final class AlertProfile {
        final String name;
        final int serviceCategory;
        final int messageClass;
        final int category;
        final int responseType;
        final int severity;
        final int urgency;
        final int certainty;

        AlertProfile(String name, int serviceCategory, int messageClass, int category,
                int responseType, int severity, int urgency, int certainty) {
            this.name = name;
            this.serviceCategory = serviceCategory;
            this.messageClass = messageClass;
            this.category = category;
            this.responseType = responseType;
            this.severity = severity;
            this.urgency = urgency;
            this.certainty = certainty;
        }

        static AlertProfile from(String type, int customCategory) {
            String normalized = type == null ? "extreme" : type.toLowerCase();
            if ("presidential".equals(normalized)) {
                return new AlertProfile("presidential", 0x1112, 0, -1, -1, 0, 1, 1);
            } else if ("severe".equals(normalized)) {
                return new AlertProfile("severe", 0x1119, 2, -1, -1, 1, 0, 1);
            } else if ("amber".equals(normalized)) {
                return new AlertProfile("amber", 0x111B, 3, -1, -1, -1, -1, -1);
            } else if ("monthly-test".equals(normalized)) {
                return new AlertProfile("monthly-test", 0x111C, 4, -1, -1, -1, -1, -1);
            } else if ("exercise".equals(normalized)) {
                return new AlertProfile("exercise", 0x111D, 5, -1, -1, -1, -1, -1);
            } else if ("public-safety".equals(normalized)) {
                return new AlertProfile("public-safety", 0x112C, 6, -1, -1, -1, -1, -1);
            } else if ("state-local-test".equals(normalized)) {
                return new AlertProfile("state-local-test", 0x112E, 7, -1, -1, -1, -1, -1);
            } else if ("custom".equals(normalized)) {
                return new AlertProfile("custom", customCategory, -1, -1, -1, -1, -1, -1);
            }
            return new AlertProfile("extreme", 0x1113, 1, -1, -1, 0, 1, 0);
        }
    }

    private static final class Args {
        String type = "extreme";
        String body = "This is a local Android Emulator emergency alert test.";
        String language = "en";
        String receiverPackage = "auto";
        String plmn = "310260";
        int serialNumber = (int) (System.currentTimeMillis() & 0xFFFF);
        int category = 0x1113;
        int slotIndex = 0;
        int subId = -1;
        int maximumWaitSeconds = 0;
        boolean cdma = false;
        boolean priorityNormal = false;

        static Args parse(String[] argv) {
            Args args = new Args();
            for (int i = 0; i < argv.length; i++) {
                String key = argv[i];
                String value = i + 1 < argv.length ? argv[++i] : "";
                if ("--type".equals(key)) {
                    args.type = value;
                } else if ("--body".equals(key)) {
                    args.body = value;
                } else if ("--body-b64".equals(key)) {
                    args.body = new String(Base64.getDecoder().decode(value),
                            StandardCharsets.UTF_8);
                } else if ("--language".equals(key)) {
                    args.language = value;
                } else if ("--serial".equals(key)) {
                    args.serialNumber = parseInt(value, args.serialNumber);
                } else if ("--category".equals(key)) {
                    args.category = parseInt(value, args.category);
                } else if ("--package".equals(key)) {
                    args.receiverPackage = value;
                } else if ("--plmn".equals(key)) {
                    args.plmn = value;
                } else if ("--slot".equals(key)) {
                    args.slotIndex = parseInt(value, args.slotIndex);
                } else if ("--sub-id".equals(key)) {
                    args.subId = parseInt(value, args.subId);
                } else if ("--max-wait".equals(key)) {
                    args.maximumWaitSeconds = parseInt(value, args.maximumWaitSeconds);
                } else if ("--format".equals(key)) {
                    args.cdma = "cdma".equalsIgnoreCase(value)
                            || "3gpp2".equalsIgnoreCase(value);
                } else if ("--priority".equals(key)) {
                    args.priorityNormal = "normal".equalsIgnoreCase(value);
                }
            }
            if (args.language == null || args.language.length() == 0) {
                args.language = "en";
            }
            return args;
        }

        private static int parseInt(String value, int fallback) {
            try {
                if (value == null || value.length() == 0) {
                    return fallback;
                }
                if (value.startsWith("0x") || value.startsWith("0X")) {
                    return Integer.parseInt(value.substring(2), 16);
                }
                return Integer.parseInt(value);
            } catch (NumberFormatException ignored) {
                return fallback;
            }
        }
    }
}
