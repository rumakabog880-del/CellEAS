param(
    [string]$ApiLevel = "30",
    [string]$SystemImage = "default;x86_64",
    [string]$AvdName = "CBLab_API30"
)

$ErrorActionPreference = "Stop"

function Write-Step([string]$Message) {
    Write-Host ""
    Write-Host "== $Message" -ForegroundColor Cyan
}

function Invoke-Tool {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [string]$InputText = "",
        [int]$TimeoutSeconds = 0
    )

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $FilePath
    $psi.Arguments = ($Arguments | ForEach-Object { Quote-WindowsArg $_ }) -join " "
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.RedirectStandardInput = $InputText.Length -gt 0
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    $stdoutBuilder = New-Object System.Text.StringBuilder
    $stderrBuilder = New-Object System.Text.StringBuilder
    $process.add_OutputDataReceived({
        if ($null -ne $_.Data) {
            [void]$stdoutBuilder.AppendLine($_.Data)
            Write-Host $_.Data
        }
    })
    $process.add_ErrorDataReceived({
        if ($null -ne $_.Data) {
            [void]$stderrBuilder.AppendLine($_.Data)
            Write-Host $_.Data -ForegroundColor DarkYellow
        }
    })
    [void]$process.Start()
    $process.BeginOutputReadLine()
    $process.BeginErrorReadLine()
    if ($InputText.Length -gt 0) {
        $process.StandardInput.Write($InputText)
        $process.StandardInput.Close()
    }
    if ($TimeoutSeconds -gt 0) {
        if (-not $process.WaitForExit($TimeoutSeconds * 1000)) {
            $process.Kill()
            throw "Timed out: $FilePath $($psi.Arguments)"
        }
    } else {
        $process.WaitForExit()
    }
    $process.WaitForExit()
    if ($process.ExitCode -ne 0) {
        throw "Command failed ($($process.ExitCode)): $FilePath $($psi.Arguments)"
    }
}

function Quote-WindowsArg([string]$Value) {
    if ($Value -notmatch '[\s"]') {
        return $Value
    }
    return '"' + $Value.Replace('"', '\"') + '"'
}

function Download-FileIfMissing([string]$Url, [string]$OutFile) {
    if (Test-Path -LiteralPath $OutFile) {
        Write-Host "Already downloaded: $OutFile"
        return
    }
    Write-Host "Downloading $Url"
    Invoke-WebRequest -Uri $Url -OutFile $OutFile
}

function Accept-AndroidLicenses([string]$SdkManagerPath, [string]$SdkRootPath) {
    $yes = ("y`r`n" * 200)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "cmd.exe"
    $escapedSdkManager = $SdkManagerPath.Replace('"', '""')
    $escapedSdkRoot = $SdkRootPath.Replace('"', '""')
    $psi.Arguments = "/d /s /c """"$escapedSdkManager"" --sdk_root=""$escapedSdkRoot"" --licenses"""
    $psi.UseShellExecute = $false
    $psi.RedirectStandardInput = $true
    $psi.RedirectStandardOutput = $false
    $psi.RedirectStandardError = $false
    $psi.EnvironmentVariables["JAVA_HOME"] = $env:JAVA_HOME
    $psi.EnvironmentVariables["PATH"] = (Join-Path $env:JAVA_HOME "bin") + ";" + $env:PATH
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi
    [void]$process.Start()
    $process.StandardInput.Write($yes)
    $process.StandardInput.Close()
    if (-not $process.WaitForExit(180000)) {
        $process.Kill()
        throw "Timed out while accepting Android SDK licenses"
    }
    if ($process.ExitCode -ne 0) {
        throw "Android SDK license command failed with exit code $($process.ExitCode)"
    }
}

function Find-JdkRoot([string]$ToolsDir) {
    $javac = Get-ChildItem -LiteralPath $ToolsDir -Recurse -Filter javac.exe -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if (-not $javac) {
        return $null
    }
    return (Split-Path -Parent (Split-Path -Parent $javac.FullName))
}

function Find-D8([string]$SdkRoot) {
    $d8 = Get-ChildItem -LiteralPath (Join-Path $SdkRoot "build-tools") -Recurse -Filter d8.bat -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending |
        Select-Object -First 1
    if (-not $d8) {
        throw "d8.bat not found under $SdkRoot\build-tools"
    }
    return $d8.FullName
}

function Build-Injector([string]$SdkRoot, [string]$JdkRoot, [string]$Root, [string]$Workspace) {
    Write-Step "Building in-emulator injector"
    $javac = Join-Path $JdkRoot "bin\javac.exe"
    $d8 = Find-D8 $SdkRoot
    $androidJar = Join-Path $SdkRoot "platforms\android-$ApiLevel\android.jar"
    if (-not (Test-Path -LiteralPath $androidJar)) {
        throw "Missing Android platform jar: $androidJar"
    }

    $buildRoot = Join-Path $Workspace "work\build\injector"
    $classes = Join-Path $buildRoot "classes"
    $dexOut = Join-Path $buildRoot "dex"
    $classesJar = Join-Path $buildRoot "injector-classes.jar"
    Remove-Item -LiteralPath $buildRoot -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $classes, $dexOut | Out-Null

    $source = Join-Path $Root "injector-src\com\local\cb\CellBroadcastInjector.java"
    & $javac "-source" "8" "-target" "8" "-cp" $androidJar "-d" $classes $source
    if ($LASTEXITCODE -ne 0) {
        throw "javac failed with exit code $LASTEXITCODE"
    }
    & (Join-Path $JdkRoot "bin\jar.exe") "cf" $classesJar "-C" $classes "."
    if ($LASTEXITCODE -ne 0) {
        throw "jar failed with exit code $LASTEXITCODE"
    }
    & $d8 "--min-api" "30" "--output" $dexOut $classesJar
    if ($LASTEXITCODE -ne 0) {
        throw "d8 failed with exit code $LASTEXITCODE"
    }

    $jar = Join-Path $Root "cellbroadcast-injector.jar"
    Remove-Item -LiteralPath $jar -Force -ErrorAction SilentlyContinue
    & (Join-Path $JdkRoot "bin\jar.exe") "cf" $jar "-C" $dexOut "classes.dex"
    if ($LASTEXITCODE -ne 0) {
        throw "jar dex packaging failed with exit code $LASTEXITCODE"
    }
    Write-Host "Built: $jar" -ForegroundColor Green
}

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Workspace = Split-Path -Parent (Split-Path -Parent $Root)
$ToolsDir = Join-Path $Workspace "work\tools"
$SdkRoot = Join-Path $Workspace "work\android-sdk"
$AvdHome = Join-Path $Workspace "work\avd"
$AndroidUserHome = Join-Path $Workspace "work\android-user-home"

New-Item -ItemType Directory -Force -Path $ToolsDir, $SdkRoot, $AvdHome, $AndroidUserHome | Out-Null

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Step "Downloading portable JDK"
$jdkZip = Join-Path $ToolsDir "temurin-jdk21-windows-x64.zip"
$jdkUrl = "https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse"
Download-FileIfMissing $jdkUrl $jdkZip
$JdkRoot = Find-JdkRoot $ToolsDir
if (-not $JdkRoot) {
    Expand-Archive -LiteralPath $jdkZip -DestinationPath $ToolsDir -Force
    $JdkRoot = Find-JdkRoot $ToolsDir
}
if (-not $JdkRoot) {
    throw "Could not locate javac.exe after extracting JDK"
}
Write-Host "JDK: $JdkRoot"

$env:JAVA_HOME = $JdkRoot
$env:PATH = (Join-Path $JdkRoot "bin") + ";" + $env:PATH
$env:ANDROID_AVD_HOME = $AvdHome
$env:ANDROID_USER_HOME = $AndroidUserHome
$env:ANDROID_SDK_ROOT = $SdkRoot
$env:ANDROID_HOME = $SdkRoot

Write-Step "Installing Android command-line tools"
$cmdlineZip = Join-Path $ToolsDir "commandlinetools-win-14742923_latest.zip"
$cmdlineUrl = "https://dl.google.com/android/repository/commandlinetools-win-14742923_latest.zip"
Download-FileIfMissing $cmdlineUrl $cmdlineZip
$sdkManager = Join-Path $SdkRoot "cmdline-tools\latest\bin\sdkmanager.bat"
if (-not (Test-Path -LiteralPath $sdkManager)) {
    $latest = Join-Path $SdkRoot "cmdline-tools\latest"
    Remove-Item -LiteralPath $latest -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $latest | Out-Null
    & tar -xf $cmdlineZip -C $latest --strip-components=1
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to extract Android command-line tools with tar"
    }
}

$sdkManagerLib = Join-Path $SdkRoot "cmdline-tools\latest\lib\sdklib\libsdkmanager_lib.jar"
$kotlinStdlib = Join-Path $SdkRoot "cmdline-tools\latest\lib\external\org\jetbrains\kotlin\kotlin-stdlib\2.2.10\kotlin-stdlib-2.2.10.jar"
if (-not (Test-Path -LiteralPath $sdkManagerLib) -or -not (Test-Path -LiteralPath $kotlinStdlib)) {
    Write-Host "Completing command-line tools extraction."
    $latest = Join-Path $SdkRoot "cmdline-tools\latest"
    & tar -xf $cmdlineZip -C $latest --strip-components=1 `
        "cmdline-tools/lib/sdklib" `
        "cmdline-tools/lib/repository" `
        "cmdline-tools/lib/sdk-common" `
        "cmdline-tools/lib/external" `
        "cmdline-tools/lib/layoutlib-api" `
        "cmdline-tools/lib/misc" `
        "cmdline-tools/lib/zipflinger" `
        "cmdline-tools/lib/profgen"
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $sdkManagerLib) `
            -or -not (Test-Path -LiteralPath $kotlinStdlib)) {
        throw "Android command-line tools extraction is incomplete"
    }
}

Write-Step "Accepting SDK licenses"
try {
    Accept-AndroidLicenses $sdkManager $SdkRoot
} catch {
    Write-Host "License pass reported a non-zero status; continuing to package install." -ForegroundColor DarkYellow
}

Write-Step "Installing SDK packages"
$yes = ("y`n" * 200)
$packages = @(
    "platform-tools",
    "emulator",
    "platforms;android-$ApiLevel",
    "build-tools;35.0.0",
    "system-images;android-$ApiLevel;$SystemImage"
)
foreach ($package in $packages) {
    Write-Host "Installing/checking $package"
    & $sdkManager "--sdk_root=$SdkRoot" $package
    if ($LASTEXITCODE -ne 0) {
        throw "sdkmanager failed for $package with exit code $LASTEXITCODE"
    }
}

Write-Step "Creating local AVD"
$avdManager = Join-Path $SdkRoot "cmdline-tools\latest\bin\avdmanager.bat"
$imagePackage = "system-images;android-$ApiLevel;$SystemImage"
try {
    "no" | & $avdManager "create" "avd" "-n" $AvdName "-k" $imagePackage `
        "--device" "pixel_6" "--force"
    if ($LASTEXITCODE -ne 0) {
        throw "avdmanager failed with pixel_6"
    }
} catch {
    Write-Host "Retrying AVD creation with generic pixel profile." -ForegroundColor DarkYellow
    "no" | & $avdManager "create" "avd" "-n" $AvdName "-k" $imagePackage `
        "--device" "pixel" "--force"
    if ($LASTEXITCODE -ne 0) {
        throw "avdmanager failed with pixel"
    }
}

Build-Injector $SdkRoot $JdkRoot $Root $Workspace

Write-Step "Writing local config"
$config = @"
sdkRoot=$SdkRoot
avdHome=$AvdHome
androidUserHome=$AndroidUserHome
avdName=$AvdName
apiLevel=$ApiLevel
"@
Set-Content -LiteralPath (Join-Path $Root "lab.properties") -Value $config -Encoding ASCII

Write-Host ""
Write-Host "Done. Launch CellBroadcastLab.exe, start $AvdName, then send a test alert." -ForegroundColor Green
