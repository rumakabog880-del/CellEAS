using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace CellBroadcastLabHost
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    internal sealed class MainForm : Form
    {
        private readonly string root;
        private readonly string workspace;
        private readonly Dictionary<string, string> config = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        private TextBox sdkRootBox;
        private TextBox adbPathBox;
        private TextBox avdNameBox;
        private ComboBox deviceBox;
        private ComboBox typeBox;
        private TextBox bodyBox;
        private TextBox languageBox;
        private TextBox serialBox;
        private TextBox categoryBox;
        private TextBox packageBox;
        private CheckBox adbRootBox;
        private RichTextBox logBox;

        public MainForm()
        {
            root = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
            workspace = Directory.GetParent(Directory.GetParent(root).FullName).FullName;
            LoadConfig();
            BuildUi();
            RefreshDerivedPaths();
            RefreshDevices();
        }

        private void BuildUi()
        {
            Text = "Cell Broadcast Lab - Android Emulator";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(920, 720);
            Size = new Size(1040, 800);
            Font = new Font("Segoe UI", 9F);

            TableLayoutPanel main = new TableLayoutPanel();
            main.Dock = DockStyle.Fill;
            main.ColumnCount = 1;
            main.RowCount = 4;
            main.Padding = new Padding(12);
            main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            main.RowStyles.Add(new RowStyle(SizeType.Percent, 55F));
            main.RowStyles.Add(new RowStyle(SizeType.Percent, 45F));
            Controls.Add(main);

            Label title = new Label();
            title.AutoSize = true;
            title.Font = new Font(Font.FontFamily, 14F, FontStyle.Bold);
            title.Text = "Local Android Emulator Cell Broadcast injector";
            main.Controls.Add(title, 0, 0);

            Label subtitle = new Label();
            subtitle.AutoSize = true;
            subtitle.ForeColor = Color.DimGray;
            subtitle.Padding = new Padding(0, 4, 0, 8);
            subtitle.Text = "Emulator-only guard is enforced here. The Android system CellBroadcastReceiver draws the alert window.";
            main.Controls.Add(subtitle, 0, 1);

            TableLayoutPanel grid = new TableLayoutPanel();
            grid.Dock = DockStyle.Fill;
            grid.ColumnCount = 4;
            grid.RowCount = 9;
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            main.Controls.Add(grid, 0, 2);

            sdkRootBox = AddText(grid, "SDK root", 0, GetConfig("sdkRoot", Path.Combine(workspace, "work", "android-sdk")));
            Button installButton = AddButton(grid, "Install / build SDK", 0, 2);
            installButton.Click += delegate { StartInstaller(); };

            adbPathBox = AddText(grid, "adb.exe", 1, "");
            Button refreshButton = AddButton(grid, "Refresh devices", 1, 2);
            refreshButton.Click += delegate { RefreshDevices(); };

            avdNameBox = AddText(grid, "AVD name", 2, GetConfig("avdName", "CBLab_API30"));
            Button startButton = AddButton(grid, "Start emulator", 2, 2);
            startButton.Click += delegate { StartEmulator(); };

            deviceBox = new ComboBox();
            deviceBox.DropDownStyle = ComboBoxStyle.DropDownList;
            deviceBox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            AddLabel(grid, "Device", 3, 0);
            grid.Controls.Add(deviceBox, 1, 3);
            grid.SetColumnSpan(deviceBox, 1);
            adbRootBox = new CheckBox();
            adbRootBox.Text = "adb root before send";
            adbRootBox.Checked = true;
            adbRootBox.Anchor = AnchorStyles.Left;
            grid.Controls.Add(adbRootBox, 2, 3);
            Button checkButton = AddButton(grid, "Check emulator", 3, 3);
            checkButton.Click += delegate { CheckEmulator(); };

            typeBox = new ComboBox();
            typeBox.DropDownStyle = ComboBoxStyle.DropDownList;
            typeBox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            typeBox.Items.Add("Extreme threat (CMAS 0x1113)");
            typeBox.Items.Add("Severe threat (CMAS 0x1119)");
            typeBox.Items.Add("AMBER / child abduction (CMAS 0x111B)");
            typeBox.Items.Add("Presidential level (CMAS 0x1112)");
            typeBox.Items.Add("Required monthly test (CMAS 0x111C)");
            typeBox.Items.Add("Exercise (CMAS 0x111D)");
            typeBox.Items.Add("Public safety (CMAS 0x112C)");
            typeBox.Items.Add("State/local test (CMAS 0x112E)");
            typeBox.Items.Add("Custom category");
            typeBox.SelectedIndex = 0;
            AddLabel(grid, "Alert type", 4, 0);
            grid.Controls.Add(typeBox, 1, 4);

            categoryBox = AddText(grid, "Custom category", 4, "0x1113");
            languageBox = AddText(grid, "Language", 5, "en");
            serialBox = AddText(grid, "Serial", 5, ((int)(DateTime.UtcNow.Ticks & 0xFFFF)).ToString());
            packageBox = AddText(grid, "Receiver package", 6, "auto");

            Button unlockButton = AddButton(grid, "Dismiss keyguard", 6, 2);
            unlockButton.Click += delegate { DismissKeyguard(); };

            bodyBox = new TextBox();
            bodyBox.Multiline = true;
            bodyBox.ScrollBars = ScrollBars.Vertical;
            bodyBox.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;
            bodyBox.Text = "LOCAL EMULATOR TEST. This is a Cell Broadcast emergency alert generated locally for Android Emulator research.";
            AddLabel(grid, "Message text", 7, 0);
            grid.Controls.Add(bodyBox, 1, 7);
            grid.SetColumnSpan(bodyBox, 3);
            grid.RowStyles.Add(new RowStyle(SizeType.Absolute, 86F));

            Button sendButton = new Button();
            sendButton.Text = "Send system emergency alert";
            sendButton.Height = 34;
            sendButton.Dock = DockStyle.Fill;
            sendButton.Click += delegate { SendAlert(); };
            grid.Controls.Add(sendButton, 1, 8);
            grid.SetColumnSpan(sendButton, 3);

            logBox = new RichTextBox();
            logBox.Dock = DockStyle.Fill;
            logBox.ReadOnly = true;
            logBox.BackColor = Color.FromArgb(248, 248, 248);
            logBox.BorderStyle = BorderStyle.FixedSingle;
            logBox.Font = new Font("Consolas", 9F);
            main.Controls.Add(logBox, 0, 3);

            AppendLog("Ready. Run Install / build SDK first if adb/emulator are not installed yet.");
        }

        private TextBox AddText(TableLayoutPanel grid, string label, int row, string value)
        {
            int labelColumn = row == 4 || row == 5 || row == 6 ? (label == "Custom category" || label == "Serial" ? 2 : 0) : 0;
            int inputColumn = labelColumn + 1;
            AddLabel(grid, label, row, labelColumn);
            TextBox box = new TextBox();
            box.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            box.Text = value;
            grid.Controls.Add(box, inputColumn, row);
            return box;
        }

        private void AddLabel(TableLayoutPanel grid, string text, int row, int col)
        {
            Label label = new Label();
            label.Text = text;
            label.AutoSize = true;
            label.Anchor = AnchorStyles.Left;
            label.Margin = new Padding(0, 7, 8, 7);
            grid.Controls.Add(label, col, row);
        }

        private Button AddButton(TableLayoutPanel grid, string text, int row, int col)
        {
            Button button = new Button();
            button.Text = text;
            button.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            button.Height = 28;
            grid.Controls.Add(button, col, row);
            if (col == 2)
            {
                grid.SetColumnSpan(button, 2);
            }
            return button;
        }

        private void LoadConfig()
        {
            string file = Path.Combine(root, "lab.properties");
            if (!File.Exists(file))
            {
                return;
            }
            foreach (string line in File.ReadAllLines(file))
            {
                int pos = line.IndexOf('=');
                if (pos <= 0)
                {
                    continue;
                }
                config[line.Substring(0, pos).Trim()] = line.Substring(pos + 1).Trim();
            }
        }

        private string GetConfig(string key, string fallback)
        {
            string value;
            return config.TryGetValue(key, out value) && value.Length > 0 ? value : fallback;
        }

        private void RefreshDerivedPaths()
        {
            string sdk = sdkRootBox.Text.Trim();
            if (adbPathBox.Text.Trim().Length == 0)
            {
                adbPathBox.Text = Path.Combine(sdk, "platform-tools", "adb.exe");
            }
        }

        private void StartInstaller()
        {
            string script = Path.Combine(root, "Install-AndroidSdk.ps1");
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = "powershell.exe";
            psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File " + QuoteWin(script);
            psi.WorkingDirectory = root;
            psi.UseShellExecute = true;
            Process.Start(psi);
            AppendLog("Started installer in a separate PowerShell window.");
        }

        private void StartEmulator()
        {
            try
            {
                string emulator = Path.Combine(sdkRootBox.Text.Trim(), "emulator", "emulator.exe");
                if (!File.Exists(emulator))
                {
                    AppendLog("Missing emulator.exe: " + emulator);
                    return;
                }
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = emulator;
                psi.Arguments = "-avd " + QuoteWin(avdNameBox.Text.Trim());
                psi.WorkingDirectory = Path.GetDirectoryName(emulator);
                psi.UseShellExecute = false;
                psi.EnvironmentVariables["ANDROID_AVD_HOME"] = GetConfig("avdHome", Path.Combine(workspace, "work", "avd"));
                psi.EnvironmentVariables["ANDROID_USER_HOME"] = GetConfig("androidUserHome", Path.Combine(workspace, "work", "android-user-home"));
                psi.EnvironmentVariables["ANDROID_SDK_ROOT"] = sdkRootBox.Text.Trim();
                psi.EnvironmentVariables["ANDROID_HOME"] = sdkRootBox.Text.Trim();
                Process.Start(psi);
                AppendLog("Started emulator AVD: " + avdNameBox.Text.Trim());
            }
            catch (Exception ex)
            {
                AppendLog("Start emulator failed: " + ex.Message);
            }
        }

        private void RefreshDevices()
        {
            try
            {
                RefreshDerivedPaths();
                deviceBox.Items.Clear();
                if (!File.Exists(adbPathBox.Text.Trim()))
                {
                    AppendLog("adb.exe not found. Run installer or set adb path.");
                    return;
                }
                CommandResult result = Run(adbPathBox.Text.Trim(), "devices", 15000);
                foreach (string raw in result.Output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    string line = raw.Trim();
                    if (!line.StartsWith("emulator-", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    string[] parts = line.Split(new[] { '\t', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length >= 2 && parts[1] == "device")
                    {
                        deviceBox.Items.Add(parts[0]);
                    }
                }
                if (deviceBox.Items.Count > 0)
                {
                    deviceBox.SelectedIndex = 0;
                    AppendLog("Found emulator device(s): " + deviceBox.Items.Count);
                }
                else
                {
                    AppendLog("No running emulator-* device found.");
                }
            }
            catch (Exception ex)
            {
                AppendLog("Refresh failed: " + ex.Message);
            }
        }

        private void CheckEmulator()
        {
            string device = SelectedDevice();
            if (device == null)
            {
                return;
            }
            AppendLog("Checking " + device);
            RunAdb("-s " + QuoteWin(device) + " shell getprop ro.build.type", 20000);
            RunAdb("-s " + QuoteWin(device) + " shell getprop ro.debuggable", 20000);
            RunAdb("-s " + QuoteWin(device) + " shell pm list packages cellbroadcast", 20000);
            RunAdb("-s " + QuoteWin(device) + " shell cmd package resolve-activity android.settings.WIRELESS_SETTINGS", 20000);
        }

        private void DismissKeyguard()
        {
            string device = SelectedDevice();
            if (device == null)
            {
                return;
            }
            RunAdb("-s " + QuoteWin(device) + " shell wm dismiss-keyguard", 15000);
            RunAdb("-s " + QuoteWin(device) + " shell input keyevent 82", 15000);
        }

        private void SendAlert()
        {
            string device = SelectedDevice();
            if (device == null)
            {
                return;
            }
            if (!device.StartsWith("emulator-", StringComparison.OrdinalIgnoreCase))
            {
                AppendLog("Refusing to send: selected device is not an Android Emulator serial.");
                return;
            }

            string jar = Path.Combine(root, "cellbroadcast-injector.jar");
            if (!File.Exists(jar))
            {
                AppendLog("Missing injector jar. Run Install / build SDK first.");
                return;
            }

            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (adbRootBox.Checked)
                {
                    RunAdb("-s " + QuoteWin(device) + " root", 30000);
                    Thread.Sleep(2500);
                    RunAdb("-s " + QuoteWin(device) + " wait-for-device", 30000);
                }

                RunAdb("-s " + QuoteWin(device) + " push " + QuoteWin(jar) + " /data/local/tmp/cellbroadcast-injector.jar", 30000);
                DismissKeyguard();

                List<string> remoteArgs = new List<string>();
                remoteArgs.Add("--type");
                remoteArgs.Add(SelectedTypeKey());
                remoteArgs.Add("--body-b64");
                remoteArgs.Add(Convert.ToBase64String(Encoding.UTF8.GetBytes(bodyBox.Text)));
                remoteArgs.Add("--language");
                remoteArgs.Add(languageBox.Text.Trim().Length == 0 ? "en" : languageBox.Text.Trim());
                remoteArgs.Add("--serial");
                remoteArgs.Add(serialBox.Text.Trim());
                remoteArgs.Add("--package");
                remoteArgs.Add(packageBox.Text.Trim().Length == 0 ? "auto" : packageBox.Text.Trim());
                if (SelectedTypeKey() == "custom")
                {
                    remoteArgs.Add("--category");
                    remoteArgs.Add(categoryBox.Text.Trim());
                }

                StringBuilder remote = new StringBuilder();
                remote.Append("CLASSPATH=/data/local/tmp/cellbroadcast-injector.jar ");
                remote.Append("app_process /system/bin com.local.cb.CellBroadcastInjector");
                foreach (string arg in remoteArgs)
                {
                    remote.Append(' ');
                    remote.Append(QuoteSh(arg));
                }

                CommandResult result = RunAdb("-s " + QuoteWin(device) + " shell " + QuoteWin(remote.ToString()), 60000);
                if (result.ExitCode == 0)
                {
                    AppendLog("Alert command completed. Watch the emulator screen for the system dialog.");
                }
            }
            catch (Exception ex)
            {
                AppendLog("Send failed: " + ex.Message);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private string SelectedTypeKey()
        {
            switch (typeBox.SelectedIndex)
            {
                case 1: return "severe";
                case 2: return "amber";
                case 3: return "presidential";
                case 4: return "monthly-test";
                case 5: return "exercise";
                case 6: return "public-safety";
                case 7: return "state-local-test";
                case 8: return "custom";
                default: return "extreme";
            }
        }

        private string SelectedDevice()
        {
            if (deviceBox.SelectedItem == null)
            {
                AppendLog("No emulator selected. Start an AVD and refresh devices.");
                return null;
            }
            return deviceBox.SelectedItem.ToString();
        }

        private CommandResult RunAdb(string args, int timeoutMs)
        {
            return Run(adbPathBox.Text.Trim(), args, timeoutMs);
        }

        private CommandResult Run(string file, string args, int timeoutMs)
        {
            AppendLog("> " + file + " " + args);
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = file;
            psi.Arguments = args;
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.CreateNoWindow = true;
            if (file.EndsWith("adb.exe", StringComparison.OrdinalIgnoreCase))
            {
                psi.EnvironmentVariables["ANDROID_SDK_ROOT"] = sdkRootBox.Text.Trim();
                psi.EnvironmentVariables["ANDROID_HOME"] = sdkRootBox.Text.Trim();
            }
            Process process = new Process();
            process.StartInfo = psi;
            process.Start();
            if (!process.WaitForExit(timeoutMs))
            {
                try { process.Kill(); } catch { }
                throw new TimeoutException("Timed out after " + timeoutMs + "ms");
            }
            string output = process.StandardOutput.ReadToEnd();
            string error = process.StandardError.ReadToEnd();
            if (output.Trim().Length > 0)
            {
                AppendLog(output.TrimEnd());
            }
            if (error.Trim().Length > 0)
            {
                AppendLog(error.TrimEnd());
            }
            AppendLog("exit " + process.ExitCode);
            return new CommandResult(process.ExitCode, output + error);
        }

        private void AppendLog(string text)
        {
            if (logBox == null)
            {
                return;
            }
            logBox.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] " + text + Environment.NewLine);
            logBox.SelectionStart = logBox.TextLength;
            logBox.ScrollToCaret();
            Application.DoEvents();
        }

        private static string QuoteWin(string value)
        {
            if (value == null)
            {
                return "\"\"";
            }
            return "\"" + value.Replace("\"", "\\\"") + "\"";
        }

        private static string QuoteSh(string value)
        {
            if (value == null)
            {
                value = "";
            }
            return "'" + value.Replace("'", "'\\''") + "'";
        }
    }

    internal sealed class CommandResult
    {
        public readonly int ExitCode;
        public readonly string Output;

        public CommandResult(int exitCode, string output)
        {
            ExitCode = exitCode;
            Output = output;
        }
    }
}
